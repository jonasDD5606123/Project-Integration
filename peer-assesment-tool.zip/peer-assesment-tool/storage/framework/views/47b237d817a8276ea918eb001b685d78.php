<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Groepen Importeren</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['node_modules/bootstrap/dist/css/bootstrap.min.css', 'resources/js/import-groepen.js', 'resources/css/app.css']); ?>
</head>
<body class="bg-light-gray">
    <div class="card-container">
        <h2 class="heading-primary">Importeer Groepen</h2>

        <form id="frmGroepen" class="form-column">
            <?php echo csrf_field(); ?>
            <select id="selVakId" name="vak_id" class="input-select">
                <?php $__currentLoopData = $vakken; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vak->id); ?>"><?php echo e($vak->naam); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="file" id="inFileImport" class="input-file" />

            <table id="resultTable" class="table-styled">
                <thead>
                    <tr>
                        <th>Groep</th>
                        <th>User ID</th>
                        <th>Voornaam</th>
                        <th>Achternaam</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>

            <button type="submit" class="btn-primary">Importeer Groepen</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\moham\OneDrive\Desktop\Odisee\2de jaar\Integration Project 2\Project-Integration\Project-Integration\peer-assesment-tool\resources\views/docent/import-groepen.blade.php ENDPATH**/ ?>